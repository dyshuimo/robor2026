// Copyright (c) Redux Robotics and other contributors.
// This is open source and can be modified and shared under the 3-clause BSD license.

/**
 * Package that holds WPILib struct classes for the Canandgyro.
 */
package com.reduxrobotics.sensors.canandgyro.wpistruct;
