// Copyright (c) Redux Robotics and other contributors.
// This is open source and can be modified and shared under the 3-clause BSD license.

package com.reduxrobotics.canand;

/**
 * Class representing CAN buses that may exist on a robot.
 * 
 * <b>Currently, only the Rio's onboard CAN bus is supported.</b>
 * 
 */
public class CANBus {
    private int fd;

    private static CANBus rioBus = new CANBus((byte)0);
    CANBus(byte busDescriptor) {
        fd = busDescriptor;
    }

    /**
     * Returns a CANBus object representing the roboRIO's onboard bus.
     * @return an object representing the Rio's bus (descriptor = 0)
     */
    public static CANBus getRioBus() {
        return rioBus;
    } 

    /**
     * Returns a CANBus object corresponding to a specific bus descriptor value.
     * 
     * It is generally preferable to use this function instead of the constructor to avoid object 
     * creation churn.
     * @param busDescriptor the descriptor value
     * @return a new CANBus object associated with that bus descriptor. Equality can be checked 
     * between two CANBus objects with {@link #equals}
     */
    public static CANBus byDescriptor(byte busDescriptor) {
        if (busDescriptor == 0) {
            return rioBus;
        }
        return new CANBus(busDescriptor);
    }

    /**
     * Returns the descriptor ID associated with the CAN bus object. 
     * Generally not needed to be used directly.
     * @return the descriptor ID.
     */
    public byte getDescriptor() {
        return (byte) fd;
    }

    /**
     * Returns whether two CANBus objects refer to the same bus.
     * @param other other CANBus object to compare against
     * @return whether or not they refer to the same bus
     */
    public boolean equals(Object other) {
        return other instanceof CANBus && getDescriptor() == ((CANBus) other).getDescriptor();
    }


}
